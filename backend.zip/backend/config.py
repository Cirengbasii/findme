class Config:
    PG_HOST = "localhost"   
    PG_PORT = "5432"      
    PG_USER = "postgres"         
    PG_PASSWORD = "311204"
    PG_DB = "findme_db"          
    SECRET_KEY = "supersecretkey"